Apidoc Bootstrap 3 Template
===

This is the template of [apidoc](https://github.com/apidoc/apidoc) ported to Bootstrap 3


# Usage

Clone this repository to any directory and use it with apidoc's `template` option.

```shell
git clone https://github.com/shvelo/apidoc-bs3-template.git
cd yourproject
apidoc --template ../apidoc-bs3-template
```
